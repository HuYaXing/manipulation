/*
 Navicat Premium Data Transfer

 Source Server         : hyx
 Source Server Type    : MySQL
 Source Server Version : 50725
 Source Host           : 119.23.10.167:3306
 Source Schema         : manipulation

 Target Server Type    : MySQL
 Target Server Version : 50725
 File Encoding         : 65001

 Date: 12/04/2019 14:57:11
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for members
-- ----------------------------
DROP TABLE IF EXISTS `members`;
CREATE TABLE `members`  (
  `members_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '会员id ',
  `members_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '会员姓名',
  `pinyin_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '拼音码',
  `members_phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '手机号',
  `tuina_id` int(11) NULL DEFAULT NULL COMMENT '推拿类型id',
  `tuina_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '推拿类型',
  `surplus_number` int(11) NULL DEFAULT NULL COMMENT '剩余次数',
  PRIMARY KEY (`members_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 45618 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for record
-- ----------------------------
DROP TABLE IF EXISTS `record`;
CREATE TABLE `record`  (
  `record_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '记录id',
  `members_id` int(11) NULL DEFAULT NULL COMMENT '会员id',
  `members_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '会员名字',
  `record_time` datetime(0) NULL DEFAULT NULL COMMENT '记录时间',
  `staff_id` int(11) NULL DEFAULT NULL COMMENT '店员id',
  `staff_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '店员名',
  `tuina_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '推拿种类',
  PRIMARY KEY (`record_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 70 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for staff
-- ----------------------------
DROP TABLE IF EXISTS `staff`;
CREATE TABLE `staff`  (
  `staff_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '员工id',
  `staff_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '员工姓名',
  `pinyin_code` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '拼音码',
  `staff_phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '员工手机号',
  PRIMARY KEY (`staff_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of staff
-- ----------------------------
INSERT INTO `staff` VALUES (1, '张三', 'zs', '02065020652');
INSERT INTO `staff` VALUES (2, '李四', 'ls', '18978455623');

-- ----------------------------
-- Table structure for tuina_type
-- ----------------------------
DROP TABLE IF EXISTS `tuina_type`;
CREATE TABLE `tuina_type`  (
  `tuina_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '推拿种类id',
  `tuina_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '推拿种类',
  PRIMARY KEY (`tuina_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tuina_type
-- ----------------------------
INSERT INTO `tuina_type` VALUES (1, '小儿推拿');
INSERT INTO `tuina_type` VALUES (2, '近视治疗');

SET FOREIGN_KEY_CHECKS = 1;
